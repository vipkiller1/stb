package $package_name$.ui.activity;

import android.os.Bundle;
import $package_name$.R;
import $package_name$.common.activity.BaseActivity;

public class MainActivity extends BaseActivity { 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
    }

}